<?php

namespace Modules\SystemSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\SystemSetting\Models\SettingTaxGroup;
use Modules\SystemSetting\Models\SettingTax;
use Modules\SystemSetting\Models\SettingTaxType;



class SettingTaxGroupController extends Controller
{

    public $page = 'tax-setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function create()
    {

        $taxGroup = SettingTaxGroup::where('status', 1)->get();

        $res = [
            'taxGroup' => $taxGroup,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $data_list = SettingTaxGroup::where('tax_group_id', $request->tax_group_id)->first();
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function store(Request $request)
    {

        $data = new SettingTaxGroup;
        $data->tax_group_name = $request->tax_group_name;
        $data->save();

        $data = SettingTaxGroup::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TAX_GROUP_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_ADD');
        }
    }

    public function update(Request $request)
    {

        $tax_group_id = $request->tax_group_id;
        $Insert = $request->only('tax_group_name');
        $res = SettingTaxGroup::where('tax_group_id', $tax_group_id)->update($Insert);

        if ($res) {
            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_TAX_GROUP_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_UPDATE');
        }
    }

    public function destroy(Request $request)
    {

        $infoData =  SettingTaxGroup::findOrFail($request->tax_group_id);
        if (!empty($infoData)) {
            $infoData->tax_group_name =  $infoData->tax_group_name;
            $infoData->status = 0;
            $infoData->save();
        }

        $data = SettingTaxGroup::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOB_TYPE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TYPE_DELETE');
        }
    }
}
