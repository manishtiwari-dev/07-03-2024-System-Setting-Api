<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\SystemSetting\Http\Controllers\TaxTypeController;
use Modules\SystemSetting\Http\Controllers\SettingTaxController;
use Modules\SystemSetting\Http\Controllers\SettingTaxGroupController;
use Modules\SystemSetting\Http\Controllers\AppSettingKeyValueController;
use Modules\SystemSetting\Http\Controllers\PaymentMethodController;
use Modules\SystemSetting\Http\Controllers\ShipingMethodController;
use Modules\SystemSetting\Http\Controllers\SettingPaymentTermsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {

    //CRM crm_setting_tax API
    Route::group(['prefix' => 'crm_setting_tax'], function () {
        Route::post('/', [SettingTaxController::class, 'index']);
        Route::post('/update', [SettingTaxController::class, 'update']);
        Route::post('/changeStatus', [SettingTaxController::class, 'changeStatus']);
        Route::post('/edit', [SettingTaxController::class, 'edit']);
        Route::post('/destroy', [SettingTaxController::class, 'destroy']);
    });
    //end CRM crm_setting_tax API


    //CRM crm_setting_tax_group API
    Route::group(['prefix' => 'setting_tax_group'], function () {
        Route::post('/create', [SettingTaxGroupController::class, 'create']);
        Route::post('/store', [SettingTaxGroupController::class, 'store']);
        Route::post('/edit', [SettingTaxGroupController::class, 'edit']);
        Route::post('/update', [SettingTaxGroupController::class, 'update']);
        Route::post('/destroy', [SettingTaxGroupController::class, 'destroy']);
    });

    //end CRM crm_setting_tax_group API


    //CRM crm_setting_tax_type API
    Route::group(['prefix' => 'setting_tax_type'], function () {
        Route::post('/create', [TaxTypeController::class, 'create']);
        Route::post('/store', [TaxTypeController::class, 'store']);
        Route::post('/edit', [TaxTypeController::class, 'edit']);
        Route::post('/update', [TaxTypeController::class, 'update']);
        Route::post('/destroy', [TaxTypeController::class, 'destroy']);
    });


    //CRM crm_setting_payment_terms API
    Route::group(['prefix' => 'crm_setting_payment_terms'], function () {
        Route::post('/', [SettingPaymentTermsController::class, 'index']);
        Route::post('/store', [SettingPaymentTermsController::class, 'store']);
        Route::post('/edit', [SettingPaymentTermsController::class, 'edit']);
        Route::post('/update', [SettingPaymentTermsController::class, 'update']);
        Route::post('/changeStatus', [SettingPaymentTermsController::class, 'changeStatus']);
    });


    //general 

    Route::group(['prefix' => 'settingValue'], function () {
        Route::post('/', [AppSettingKeyValueController::class, 'index']);
        Route::post('store', [AppSettingKeyValueController::class, 'store']);
        Route::post('general_first', [AppSettingKeyValueController::class, 'general_first']);
        Route::post('general', [AppSettingKeyValueController::class, 'general']);
        Route::post('payment_first', [AppSettingKeyValueController::class, 'payment_first']);
        Route::post('payment', [AppSettingKeyValueController::class, 'payment']);
        Route::post('website_first', [AppSettingKeyValueController::class, 'website_first']);
        Route::post('website', [AppSettingKeyValueController::class, 'website']);
        Route::post('notification_first', [AppSettingKeyValueController::class, 'notification_first']);
        Route::post('notification', [AppSettingKeyValueController::class, 'notification']);
    });



    // Payment Methods prefix
    Route::group(['prefix' => 'paymentMethod'], function () {
        Route::post('/', [PaymentMethodController::class, 'index']);
        Route::post('/list', [PaymentMethodController::class, 'list']);
        Route::post('/store', [PaymentMethodController::class, 'store']);
        Route::post('/edit', [PaymentMethodController::class, 'edit']);
        Route::post('/update', [PaymentMethodController::class, 'update']);
        Route::post('/create', [PaymentMethodController::class, 'create']);
        Route::post('/paymentUpdate', [PaymentMethodController::class, 'payment_update']);
        Route::post('/changeStatus', [PaymentMethodController::class, 'changeStatus']);
    });
    // end Payment prefix

    // shipping Methods prefix
    Route::group(['prefix' => 'shippingMethod'], function () {
        Route::post('/', [ShipingMethodController::class, 'index']);
        Route::post('/list', [ShipingMethodController::class, 'list']);
        Route::post('/store', [ShipingMethodController::class, 'store']);
        Route::post('/edit', [ShipingMethodController::class, 'edit']);
        Route::post('/update', [ShipingMethodController::class, 'update']);
        Route::post('/shippingUpdate', [ShipingMethodController::class, 'shipping_update']);
        Route::post('/changeStatus', [ShipingMethodController::class, 'changeStatus']);
        Route::post('/create', [ShipingMethodController::class, 'create']);
    });
    // end  prefix



});
