<?php

namespace Modules\SystemSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\SystemSetting\Models\SettingTaxGroup;
use Modules\SystemSetting\Models\SettingTaxType;


class SettingTaxPercentage extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_id';
    protected $guarded = ['tax_id'];

    public function getTable()
    {
        return config('dbtable.crm_setting_tax_percent');
    }

    public $timestamps = false;

    public function tax_typedetails()
    {
        return $this->belongsTo(SettingTaxType::class, 'tax_type_id', 'id');
    }

    public function taxGroupDetails()
    {
        return $this->belongsTo(SettingTaxGroup::class, 'tax_group_id', 'tax_group_id');
    }
}
