<?php

namespace Modules\SystemSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\SystemSetting\Models\AppSettingGroupKey;


class AppSettingsGroup extends Model
{
    use HasFactory;
    // protected $connection='mysqlSuper';
    // protected $table = "app_settings_group";

    public $timestamps = false;
    protected $primaryKey = 'group_id';
    protected $fillable = [
        'group_name',
        'status',
        'access_privilege',
        'created_at',
        'updated_at',
    ];

    public function getTable()
    {
        return config('dbtable.app_settings_group');
    }


    public function settings()
    {
        return $this->hasMany(AppSettingGroupKey::class, 'group_id', 'group_id');
    }
}
