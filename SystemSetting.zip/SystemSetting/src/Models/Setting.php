<?php

namespace Modules\SystemSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Setting extends Model
{
    use HasFactory;
    protected $primaryKey = 'setting_key';
    protected $keyType = 'string';
    protected $fillable = [
        'setting_key',
        'setting_value'
    ];

    public function getTable()
    {
        return config('dbtable.app_setting_key_value');
    }

}
