<?php

namespace Modules\SystemSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppSettingGroupKey extends Model
{
   use HasFactory;

   //   protected $connection='mysqlSuper';
   //  protected $table = "app_setting_group_key";
   // protected $table = "website_setting";

   public $timestamps = false;
   protected $primaryKey = 'setting_id';
   protected $guarded = [
      'setting_id',
   ];

   public function getTable()
   {
      return config('dbtable.app_setting_group_key');
   }
}
