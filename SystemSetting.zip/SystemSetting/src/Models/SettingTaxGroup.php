<?php

namespace Modules\SystemSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\SystemSetting\Models\SettingTaxPercentage;

class SettingTaxGroup extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_group_id';
    protected $guarded = ['tax_group_id'];

    public function getTable()
    {
        return config('dbtable.crm_setting_tax_group');
    }

    public $timestamps = false;



    public function tax_info()
    {
        return $this->hasMany(SettingTaxPercentage::class, 'tax_group_id', 'tax_group_id');
    }
}
